package com.example.primeraApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeraApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
