/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import views.LoginView;

/**
 *
 * @author Juan Diego Orrego Vargas
 */
public class main {
    public static void main(String[] args) {
        // Instancia del login
        LoginView login = new LoginView();
        login.setVisible(true);
    }
}
